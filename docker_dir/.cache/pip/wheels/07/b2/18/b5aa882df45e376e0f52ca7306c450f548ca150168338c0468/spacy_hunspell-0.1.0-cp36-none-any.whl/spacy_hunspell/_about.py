__version__ = '0.1.0'
__author__ = 'Motoki Wu'
__email__ = 'tokestermw@gmail.com'
__url__ = 'https://github.com/tokestermw/spacy_hunspell'
